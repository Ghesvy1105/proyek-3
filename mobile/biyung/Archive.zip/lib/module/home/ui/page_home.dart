import 'dart:ui';

import 'package:biyung/core/constant.dart';
import 'package:biyung/core/layout/themedata.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class PageHome extends StatefulHookConsumerWidget {
  const PageHome({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _PageHomeState();
}

class _PageHomeState extends ConsumerState<PageHome> {
  @override
  Widget build(BuildContext context) {
    var showDetail = useState(false);

    return Stack(
      children: [
        Container(
          padding: EdgeInsets.all(gap * 3),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Cari Lauk untuk\nMakananmu!",
                  style: TextStyle(
                      fontSize: 24,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Biryani'),
                ),
                SizedBox(height: gap * 2),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(gap * 3),
                    boxShadow: [
                      const BoxShadow(
                        color: Colors.black26,
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  child: TextField(
                    decoration: InputDecoration(
                      // prefix: Container(
                      //   alignment: Alignment.centerLeft,
                      //   child: Icon(
                      //     Icons.search,
                      //     size: 24,
                      //   ),
                      // ),
                      contentPadding: EdgeInsets.all(gap * 3),
                      fillColor: Colors.white,
                      filled: true,
                      hintStyle: TextStyle(color: Colors.grey),
                      hintText: "Cari Lauk...",
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black12),
                        borderRadius: BorderRadius.circular(gap * 3),
                      ),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.blue),
                        borderRadius: BorderRadius.circular(gap * 3),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: gap * 2,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ElevatedButton(
                        onPressed: () {
                          showDetail.value = false;
                        },
                        child: Text("Semua")),
                    ElevatedButton(onPressed: () {}, child: Text("Makanan")),
                    ElevatedButton(onPressed: () {}, child: Text("Minuman")),
                  ],
                ),
                SizedBox(
                  height: gap * 3,
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text("Urutkan Berdasarkan"),
                ),
                Align(
                  alignment: Alignment.center,
                  child: Card(
                    clipBehavior: Clip.antiAlias,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(gap * 4)),
                    child: InkWell(
                      onTap: () {
                        showDetail.value = true;
                        showDialog(
                            context: context,
                            builder: (ctx) {
                              return Dialog(
                                clipBehavior: Clip.antiAlias,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30)),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Stack(
                                      children: [
                                        Hero(
                                          tag: "HERO",
                                          child: SizedBox(
                                            height: MediaQuery.of(context)
                                                    .size
                                                    .height *
                                                0.2,
                                            width: double.maxFinite,
                                            child: Image.asset(
                                              width: double.maxFinite,
                                              "assets/images/indomi.png",
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                        Container(
                                            height: MediaQuery.of(context)
                                                    .size
                                                    .height *
                                                0.2,
                                                padding: EdgeInsets.all(gap),
                                            alignment: Alignment.bottomRight,
                                            child: Icon(Icons.favorite_border,color: Colors.white,))
                                      ],
                                    ),
                                    Padding(
                                      padding: EdgeInsets.all(16),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Indomie Goreng Spesial",
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 20),
                                          ),
                                          SizedBox(
                                            height: gap,
                                          ),
                                          Text(
                                              style: TextStyle(fontSize: 12),
                                              "Merupakan  makanan olahan yang berbahan dasar dari mie instan (indomie) yang dihidangkan bersama telur ceplok. Terdapat dua jenis olahan mie untuk menu ini. yakni rebus dan goreng."),
                                          SizedBox(
                                            height: gap * 3,
                                          ),
                                          SizedBox(
                                            width: double.maxFinite,
                                            child: ElevatedButton(
                                              onPressed: () {},
                                              child: Text("Tambah"),
                                              style: ElevatedButton.styleFrom(
                                                  shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20))),
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              );
                            }).then((v) => showDetail.value = false);
                      },
                      child: Container(
                        height: MediaQuery.of(context).size.height * 0.5,
                        // height: 100,
                        child: Stack(
                          children: [
                            Hero(
                              tag: "HERO",
                              child: SizedBox(
                                  width: double.maxFinite,
                                  child: Image.asset(
                                    width: double.maxFinite,
                                    "assets/images/indomi.png",
                                    fit: BoxFit.cover,
                                  )),
                            ),
                            Align(
                              alignment: Alignment.bottomLeft,
                              child: Container(
                                // color: Colors.red,
                                padding: EdgeInsets.all(gap * 3),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Indomie Goreng\nSpecial",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 24),
                                    ),
                                    Text(
                                      "Rp. 10.000 | 40 Min",
                                      style: TextStyle(color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Align(
                                alignment: Alignment.bottomRight,
                                child: Padding(
                                  padding: EdgeInsets.all(gap * 3),
                                  child: ElevatedButton(
                                    onPressed: () {},
                                    child: Text(
                                      "Tambah",
                                      style: TextStyle(
                                          fontFamily: 'Viet',
                                          fontWeight: FontWeight.normal),
                                    ),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: warnaTri,
                                    ),
                                  ),
                                )),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),

        //FILTER
        if (showDetail.value)
          BackdropFilter(
            filter: new ImageFilter.blur(sigmaX: 3, sigmaY: 3),
            child: Container(color: Color(0x01000000)),
          ),
      ],
    );
  }
}
