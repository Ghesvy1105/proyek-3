import 'package:biyung/core/layout/layout_bottom_nav.dart';
import 'package:biyung/core/splashscreen/splashscreen.dart';
import 'package:biyung/module/home/ui/page_home.dart';
import 'package:biyung/module/singinup/ui/layout_signinup.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

final rNavKey = GlobalKey<NavigatorState>();
final GoRouter routerGo = GoRouter(
  initialLocation: "/splash",
  navigatorKey: rNavKey,
  routes: [
    ShellRoute(
      builder: (context, state, child) => Scaffold(body: child),
      routes: [
        GoRoute(
          path: '/splash',
          builder: (BuildContext context, GoRouterState state) {
            return Splashscreen();
          },
        ),
        GoRoute(
          path: '/regis',
          builder: (BuildContext context, GoRouterState state) {
            return PageRegister();
          },
        ),
      ],
    ),
    ShellRoute(
      builder: (context, state, child) => LayoutBottomNav(geget: child),
      routes: [
        GoRoute(
          path: '/',
          builder: (BuildContext context, GoRouterState state) {
            return PageHome();
          },
        ),
      ],
    ),
  ],
);
